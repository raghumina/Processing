
def setup():
    background(0)
    size(300, 400)
    
def draw():
    for i in range(10, 0, 1):
        timer 
        
    
